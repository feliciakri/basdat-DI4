CREATE OR REPLACE FUNCTION upd_stok()
RETURNS TRIGGER AS
$$
BEGIN
IF(TG_OP = 'INSERT') THEN
 UPDATE SHIPPED_PRODUK SP SET stok = stok - NEW.kuantitas
 WHERE SP.kode_produk = NEW.kode_produk;
 RETURN NEW;
END IF;

IF(TG_OP = 'UPDATE') THEN
 IF(NEW.kode_produk IS NOT NULL) THEN
  UPDATE SHIPPED_PRODUK SP SET stok = stok + NEW.kuantitas
  WHERE SP.kode_produk = OLD.kode_produk;

  UPDATE SHIPPED_PRODUK SP SET stok = stok - NEW.kuantitas
  WHERE SP.kode_produk = NEW.kode_produk;
 END IF;
 IF(NEW.kuantitas IS NOT NULL) THEN
  IF(NEW.kuantitas < OLD.kuantitas) THEN
   UPDATE SHIPPED_PRODUK SP SET stok = stok + (OLD.kuantitas - NEW.kuantitas)
   WHERE SP.kode_produk = OLD.kode_produk;
  END IF;
  IF(NEW.kuantitas > OLD.kuantitas) THEN
   UPDATE SHIPPED_PRODUK SP SET stok = stok - (NEW.kuantitas - OLD.kuantitas)
   WHERE SP.kode_produk = OLD.kode_produk;
  END IF;
 END IF;
 RETURN NEW;
END IF;

IF(TG_OP = 'DELETE') THEN
 UPDATE SHIPPED_PRODUK SP SET stok = stok + OLD.kuantitas
 WHERE SP.kode_produk = OLD.kode_produk;
END IF;
 RETURN OLD;
END;
$$
LANGUAGE plpgsql;