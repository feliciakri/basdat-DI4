$( document ).ready(function(){   
    $(".button-collapse").sideNav();
    $(".dropdown-button").dropdown();
});